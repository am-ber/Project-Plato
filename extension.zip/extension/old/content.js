chrome.runtime.onMessage.addListener(function (request) {
  if (request.action == "executeCode") {
    $("#inventoryText").val(request.data);
    $("#inventoryBtn").click();
    $("#inventoryText").val("");
    setTimeout(function () {
      $("h3:contains('ubuntu')").css("color", "red");
      chrome.runtime.sendMessage({
        data: "Hello"
      });
    }, 2000);
  }





  // Put message passing to popup here




});

//$("#inventoryText").css("background-color", "yellow");