var wait_time = 1500;

chrome.runtime.onMessage.addListener(function (request) {

  if (request.action == "1_execute") {
    $("#inventoryText").val(request.data);
    $("#inventoryBtn").click();
    $("#inventoryText").val("");
    var temp_data = [];

    setTimeout(function () {
      if ($("h3:contains('ubuntu')")) {
        temp_data.push("1_vulnerable");
        $("h3:contains('ubuntu')").css("color", "red");
        chrome.runtime.sendMessage({
          data: temp_data
        });
      } else {
        temp_data.push("1_safe");
        chrome.runtime.sendMessage({
          data: temp_data
        });
      }
    }, wait_time);
  }


  if (request.action == "2_execute") {
    $("#inventoryText").val(request.data);
    $("#inventoryBtn").click();
    $("#inventoryText").val("");
    var temp_data = [];

    setTimeout(function () {
      if ($("h5:contains('information_schema')").length > 0) {
        temp_data.push("2_vulnerable");
        $("h5:contains('information_schema')").css("color", "red");
        var start_index = 0;
        var end_index = 0;
        $("h3").each(function (i) {
          //console.log($(this).text());
          if ($(this).text() == "CHARACTER_SETS") {
            start_index = i;
          }
          if ($(this).text() == "VIEWS") {
            end_index = i;
          }
        });
        $("h3").each(function (i) {
          if (i > end_index) {
            temp_data.push($(this).text());
          }
        });

        chrome.runtime.sendMessage({
          data: temp_data
        });
      } else {
        temp_data.push("2_safe");
        chrome.runtime.sendMessage({
          data: temp_data
        });
      }
    }, wait_time);
  }


  if (request.action == "3_execute") {
    $("#inventoryText").val(request.data);
    $("#inventoryBtn").click();
    $("#inventoryText").val("");
    var temp_data = [];

    setTimeout(function () {
      if ($("h5:contains('1337')").length > 0) {
        temp_data.push("3_vulnerable");
        $("h5:contains('1337')").css("color", "red");
        chrome.runtime.sendMessage({
          data: temp_data
        });
      } else {
        temp_data.push("3_safe");
        chrome.runtime.sendMessage({
          data: temp_data
        });
      }
    }, wait_time);
  }




});

//$("#inventoryText").css("background-color", "yellow");